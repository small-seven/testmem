#include "fatal_handler.h"
#include "ace_event_error_code.h"
#include "ace_log.h"
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#include "cmsis_os.h"
#endif // OHOS_ACELITE_PRODUCT_WATCH
#include "jerryscript-port-default.h"
#include "js_fwk_common.h"
#include "presets/console_log_impl.h"
#include "presets/feature_ability_module.h"
#include "root_view.h"
#include "task_manager.h"
#include "ui_label.h"
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#endif // OHOS_ACELITE_PRODUCT_WATCH
#ifdef FEATURE_FATAL_ERROR_HANDLING
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#endif // OHOS_ACELITE_PRODUCT_WATCH
#else
#endif // FEATURE_FATAL_ERROR_HANDLING
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#endif
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#endif
