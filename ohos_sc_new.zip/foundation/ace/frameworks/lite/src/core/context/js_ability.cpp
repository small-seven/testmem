#include "js_ability.h"
#include <cstring>
#include "ace_event_error_code.h"
#include "ace_log.h"
#include "acelite_config.h"
#include "fatal_handler.h"
#include "js_ability_impl.h"
#include "js_profiler.h"
#ifdef FEATURE_ACELITE_PRODUCT_MEMORY_POOL
#include "mem_pool.h"
#endif
#ifdef FEATURE_ACELITE_PRODUCT_MEMORY_POOL
#endif // FEATURE_ACELITE_PRODUCT_MEMORY_POOL
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#endif // OHOS_ACELITE_PRODUCT_WATCH
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#endif // OHOS_ACELITE_PRODUCT_WATCH
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#endif // OHOS_ACELITE_PRODUCT_WATCH
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#endif // OHOS_ACELITE_PRODUCT_WATCH
