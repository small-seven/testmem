#include "js_framework_raw.h"
#include <cstring>
#define ACELITE_FRAMEWORK_RAW_BUFFER
#include "framework_min_bc.h"
#include "framework_min_js.h"
