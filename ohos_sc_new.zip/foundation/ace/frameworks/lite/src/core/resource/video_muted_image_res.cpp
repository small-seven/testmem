#include "acelite_config.h"
#ifdef FEATURE_COMPONENT_VIDEO
#include "video_panel_image_res.h"
#include "graphic_types.h"
#endif // FEATURE_COMPONENT_VIDEO