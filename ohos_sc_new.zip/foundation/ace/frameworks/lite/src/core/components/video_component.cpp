#include "acelite_config.h"
#ifdef FEATURE_COMPONENT_VIDEO
#include "video_component.h"
#include "ace_log.h"
#include "key_parser.h"
#include "keys.h"
#ifdef FEATURE_UPDATE_VIDEO_PROGRESS_ASYNC
#include <sys/prctl.h>
#include "ace_ability.h"
#endif // FEATURE_UPDATE_VIDEO_PROGRESS_ASYNC
#ifdef FEATURE_UPDATE_VIDEO_PROGRESS_ASYNC
#endif // FEATURE_UPDATE_VIDEO_PROGRESS_ASYN
#ifdef FEATURE_UPDATE_VIDEO_PROGRESS_ASYNC
#endif // FEATURE_UPDATE_VIDEO_PROGRESS_ASYNC
#endif // FEATURE_COMPONENT_VIDEO
