#include "text_component.h"
#include <stdlib.h>
#include <string.h>
#include "ace_log.h"
#include "font/ui_font_header.h"
#include "key_parser.h"
#include "keys.h"
