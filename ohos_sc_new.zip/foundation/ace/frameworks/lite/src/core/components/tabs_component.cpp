#include "acelite_config.h"
#ifdef FEATURE_COMPONENT_TABS
#include "ace_log.h"
#include "keys.h"
#include "tabs_component.h"
#include "ui_label.h"
#include "ui_view_group.h"
#endif // FEATURE_COMPONENT_TABS
