#include "acelite_config.h"
#ifdef FEATURE_COMPONENT_CAMERA
#include "camera_component.h"
#include <fstream>
#include <sstream>
#include <string>
#include "ability_env.h"
#include "ace_log.h"
#include "ace_mem_base.h"
#include "js_async_work.h"
#include "key_parser.h"
#include "keys.h"
#include <sys/time.h>
#endif // FEATURE_COMPONENT_CAMERA