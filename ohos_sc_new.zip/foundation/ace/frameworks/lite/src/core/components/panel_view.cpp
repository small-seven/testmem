#include "acelite_config.h"
#ifdef FEATURE_COMPONENT_VIDEO
#include "panel_view.h"
#include "graphic_config.h"
#endif // FEATURE_COMPONENT_VIDEO