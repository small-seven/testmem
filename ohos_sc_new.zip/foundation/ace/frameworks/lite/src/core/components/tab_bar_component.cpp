#include "acelite_config.h"
#ifdef FEATURE_COMPONENT_TABS
#include "js_fwk_common.h"
#include "key_parser.h"
#include "keys.h"
#include "tab_bar_component.h"
#include "ui_label.h"
#include "ace_log.h"
#include "ace_mem_base.h"
#endif // FEATURE_COMPONENT_TABS
