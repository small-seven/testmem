#include "acelite_config.h"
#ifdef FEATURE_COMPONENT_VIDEO
#include "video_view.h"
#include "video_state_callback.h"
#endif // FEATURE_COMPONENT_VIDEO
