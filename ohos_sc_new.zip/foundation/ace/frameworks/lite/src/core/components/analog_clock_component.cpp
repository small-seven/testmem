#include "acelite_config.h"
#ifdef FEATURE_COMPONENT_ANALOG_CLOCK
#include "ace_log.h"
#include "analog_clock_component.h"
#include "keys.h"
#include "ui_image_view.h"
#endif // FEATURE_COMPONENT_ANALOG_CLOCK
