#include "scroll_layer.h"
#include "ace_log.h"
#include "component_utils.h"
#include "root_view.h"
#ifdef FEATURE_ROOTVIEW_CUSTOM_BACKGROUND_COLOR
#endif
