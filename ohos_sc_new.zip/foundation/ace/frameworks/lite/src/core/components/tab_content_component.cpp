#include "acelite_config.h"
#ifdef FEATURE_COMPONENT_TABS
#include "js_fwk_common.h"
#include "keys.h"
#include "tab_content_component.h"
#include "ui_view_group.h"
#endif // FEATURE_COMPONENT_TABS
