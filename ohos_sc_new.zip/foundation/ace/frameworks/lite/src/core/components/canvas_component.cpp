#include "acelite_config.h"
#ifdef FEATURE_COMPONENT_CANVAS
#include "canvas_component.h"
#include "js_fwk_common.h"
#endif // FEATURE_COMPONENT_CANVAS
