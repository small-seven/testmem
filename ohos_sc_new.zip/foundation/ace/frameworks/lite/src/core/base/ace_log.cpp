#include "ace_log.h"
#include <stdarg.h>
#include <stdio.h>
#if (defined(_WIN32) || defined(_WIN64))
#endif
