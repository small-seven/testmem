#include "js_debugger_config.h"
#include <cstring>
#include "ace_log.h"
#include "debugger.h"
#include "handler.h"
#include "jerryscript-port-default.h"
#include "jerryscript-port.h"
#include "js_fwk_common.h"
#if ENABLED(ENGINE_DEBUGGER)
#ifdef JS_ENGINE_EXTERNAL_CONTEXT
#endif // JS_ENGINE_EXTERNAL_CONTEXT
#ifdef JS_ENGINE_EXTERNAL_CONTEXT
#endif // JS_ENGINE_EXTERNAL_CONTEXT
#ifdef JS_ENGINE_EXTERNAL_CONTEXT
#endif // JS_ENGINE_EXTERNAL_CONTEXT
#else // ENABLED(ENGINE_DEBUGGER)
#endif // ENABLED(ENGINE_DEBUGGER)
