#include "jsi.h"
#include <cstdarg>
#include <cstring>
#include "acelite_config.h"
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#include "securec.h"
#endif // OHOS_ACELITE_PRODUCT_WATCH
#include "ace_log.h"
#include "ace_mem_base.h"
#include "acelite_config.h"
#include "internal/jsi_internal.h"
#include "js_fwk_common.h"
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(JS_FWK_SYMBOL)
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#endif // JS_FWK_SYMBOL
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(JS_FWK_TYPEDARRAY)
#if defined(ENABLE_JERRY)
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
#endif // JS_FWK_TYPEDARRAY
#if defined(ENABLE_JERRY)
#else
#endif
#if defined(ENABLE_JERRY)
#else
#endif
