#include "message_queue_utils.h"
#include "ace_event_error_code.h"
#include "ace_log.h"
#include "acelite_config.h"
#ifdef OHOS_ACELITE_PRODUCT_WATCH
#include "cmsis_os.h"
#endif
#if (defined(__LINUX__) || defined(__LITEOS__))
#else
#endif
#if (defined(__LINUX__) || defined(__LITEOS__))
#else
#endif
#if (defined(__LINUX__) || defined(__LITEOS__))
#else
#endif
#if (defined(__LINUX__) || defined(__LITEOS__))
#else
#endif
