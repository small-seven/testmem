#include "presets/console_module.h"
#if (defined(_WIN32) || defined(_WIN64))
#include "handler.h"
#endif /* defined(_WIN32) || defined(_WIN64) */
#if ENABLED(CONSOLE_LOG_OUTPUT)
#include "presets/console_log_impl.h"
#endif // ENABLED(CONSOLE_LOG_OUTPUT)
#if DISABLED(CONSOLE_LOG_OUTPUT)
#else
#endif /* !defined(_WIN32) && !defined(_WIN64) */
#if DISABLED(CONSOLE_LOG_OUTPUT)
#else
#endif /* !defined(_WIN32) && !defined(_WIN64) */
#if DISABLED(CONSOLE_LOG_OUTPUT)
#else
#endif /* !defined(_WIN32) && !defined(_WIN64) */
#if DISABLED(CONSOLE_LOG_OUTPUT)
#else
#endif /* !defined(_WIN32) && !defined(_WIN64) */
#if DISABLED(CONSOLE_LOG_OUTPUT)
#else
#endif /* !defined(_WIN32) && !defined(_WIN64) */
