#include "jstest_module.h"
#if (defined(JSFWK_TEST) && defined(OHOS_ACELITE_PRODUCT_WATCH))
#include <stdlib.h>
#include "ace_mem_base.h"
#include "test_fwk.h"
#endif