#include "version_module.h"
#if ENABLED(ACE_LITE_VERSION_JS_API)
#include "ace_log.h"
#include "ace_version.h"
#include "platform_adapter.h"
#endif // ENABLED(ACE_LITE_VERSION_JS_API)