#include "stylemgr/app_style_manager.h"
#include "ace_log.h"
#include "component.h"
