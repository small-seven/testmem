#include "aes_gcm.h"
#include <securec.h>
#include "hks_client.h"
#include "mbedtls/gcm.h"
#include "data_bus_error.h"
#include "os_adapter.h"
