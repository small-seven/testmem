#include <cstdio>
#include <cstdlib>
#include <getopt.h>
#include "ability_tool.h"
