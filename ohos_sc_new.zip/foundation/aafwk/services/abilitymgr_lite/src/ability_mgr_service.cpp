#include "ability_mgr_service.h"
#include <pthread.h>
#include "ability_service_interface.h"
#include "adapter.h"
#include "hos_init.h"
#include "samgr_lite.h"
#include "util/abilityms_log.h"
