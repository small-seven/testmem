#include "ability_record.h"
#include "adapter.h"
#include "securec.h"
#ifdef APP_PLATFORM_WATCHGT
#endif
