#include "app_manager.h"
#include <inttypes.h>
#include <string.h>
#include "token_generate.h"
#include "util/abilityms_log.h"
