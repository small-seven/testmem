#include "want_utils.h"
#include "element_name_utils.h"
#include <securec.h>
#ifdef OHOS_APPEXECFWK_BMS_BUNDLEMANAGER
#include <string>
#include <liteipc_adapter.h>
#endif
#include "utils.h"
#ifdef OHOS_APPEXECFWK_BMS_BUNDLEMANAGER
#endif
#ifdef OHOS_APPEXECFWK_BMS_BUNDLEMANAGER
#endif
#ifdef OHOS_APPEXECFWK_BMS_BUNDLEMANAGER
#endif
#ifdef OHOS_APPEXECFWK_BMS_BUNDLEMANAGER
#endif
