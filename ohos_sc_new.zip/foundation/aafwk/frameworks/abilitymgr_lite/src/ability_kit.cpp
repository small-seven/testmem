#include "ability_kit.h"
#include "ability_service.h"
#ifdef APP_PLATFORM_WATCHGT
#endif // APP_PLATFORM_WATCHGT
