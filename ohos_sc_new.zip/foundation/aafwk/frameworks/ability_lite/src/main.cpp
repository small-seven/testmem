#include <cerrno>
#include <climits>
#include <cstddef>
#include <sys/prctl.h>
#include "ability_thread.h"
#include "log.h"
