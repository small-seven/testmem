#include "bundle_ms_host.h"
#include <pthread.h>
#include "bundle_inner_interface.h"
#include "bundle_manager_service.h"
#include "hos_init.h"
#include "log.h"
#include "samgr_lite.h"
