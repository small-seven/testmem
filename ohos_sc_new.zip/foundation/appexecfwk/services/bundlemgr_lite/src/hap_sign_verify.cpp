#include "hap_sign_verify.h"
#include "appexecfwk_errors.h"
#include "bundle_manager_service.h"
#include "log.h"
